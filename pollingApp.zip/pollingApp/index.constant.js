angular.module("angularForm").constant('configuration', {
    apihost: 'http://144.76.34.244:3333',
});
